# Blood-Bank-Management-System-Using-Java-Jsp-Servlet-etc-
Hello Friends i am ismail and i am a software engineer.I build this project using java,jsp,servlet,html,css,Database(MySql)etc.
At first isnstall java ee in your computer then import .rar file.If your needs this project please contact me to my email and i send project all resource.
Thank You....Keep Running
